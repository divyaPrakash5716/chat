# Advanced Chatbot (Streamlit)

This is an upgraded Streamlit chatbot app that:

- Supports custom **system prompts** and **personas**
- Lets you **save/load** conversations to disk
- Accepts **uploaded text files** as contextual information
- Implements **exponential backoff** and a **rule-based fallback** if the OpenAI API fails
- Includes `Dockerfile` for containerized hosting

## How to run locally

1. Install Python 3.9+.
2. (Optional) create and activate a virtual environment.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Provide your OpenAI API key:
   - set environment variable `OPENAI_API_KEY`, or
   - paste it in the sidebar when the app runs.
5. Start the app:
   ```bash
   streamlit run app.py
   ```
6. The app will be available at `http://localhost:8501`.

## When the OpenAI API fails

The app will try to call the OpenAI API with retries. If all retries fail, a simple local rule-based assistant will respond so the chat doesn't just break. This keeps the experience usable for demos or offline testing.

## Deploying with Docker

Build and run:

```bash
docker build -t advanced-chatbot .
docker run -p 8501:8501 -e OPENAI_API_KEY=your_api_key advanced-chatbot
```

## Notes & Extensions

- This is **not** a full replacement for hosting a model; for production-grade resilience, consider:
  - adding a **database** for persistent conversation storage (Postgres, Redis),
  - integrating a **vector DB** (Milvus, Pinecone) for document retrieval,
  - adding **authentication** and rate-limiting,
  - swapping fallback with a local open-source LLM (Llama2, Mistral) if available.

