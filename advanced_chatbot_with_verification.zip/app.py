import streamlit as st
import openai
import os
import json
from datetime import datetime
from utils import (
    safe_create_chat_completion,
    simple_rule_based_fallback,
    save_conversation,
    load_conversation,
    list_saved_conversations,
)

# --- App config ---
st.set_page_config(page_title="Advanced Chatbot", page_icon="🤖", layout="wide")
st.title("🤖 Advanced Chatbot — Streamlit")

# --- Session state init ---
if "messages" not in st.session_state:
    st.session_state["messages"] = []
if "system_prompt" not in st.session_state:
    st.session_state["system_prompt"] = "You are a helpful, friendly assistant."
if "persona" not in st.session_state:
    st.session_state["persona"] = "Default"
if "api_verified" not in st.session_state:
    st.session_state["api_verified"] = False

# --- Sidebar: settings & controls ---
with st.sidebar:
    st.header("Settings & Controls")
    api_key_input = st.text_input("OpenAI API key (or set OPENAI_API_KEY env var)", type="password")
    if api_key_input:
        openai.api_key = api_key_input
        # Verify API key
        try:
            test_resp = openai.ChatCompletion.create(
                model="gpt-4o-mini",
                messages=[{"role": "system", "content": "Respond with 'pong'"}],
                max_tokens=5,
                timeout=10
            )
            if "pong" in test_resp.choices[0].message.get("content", "").lower():
                st.session_state["api_verified"] = True
                st.success("✅ API key verified and working")
            else:
                st.session_state["api_verified"] = False
                st.error("⚠ API key set, but test failed")
        except Exception as e:
            st.session_state["api_verified"] = False
            st.error(f"❌ API key set but request failed: {e}")
    elif os.getenv("OPENAI_API_KEY"):
        openai.api_key = os.getenv("OPENAI_API_KEY")
        st.info("Using OPENAI_API_KEY from environment (not yet verified)")

    st.markdown("---")
    st.subheader("System prompt")
    sp = st.text_area("System instructions for the assistant", st.session_state["system_prompt"], height=140)
    if st.button("Update system prompt"):
        st.session_state["system_prompt"] = sp
        st.success("System prompt updated")

    st.markdown("---")
    st.subheader("Personas")
    persona = st.selectbox("Choose a persona", ["Default", "Friendly Teacher", "Concise Assistant", "Coder", "Creative Writer"])
    if st.button("Set persona"):
        st.session_state["persona"] = persona
        st.success(f"Persona set: {persona}")

    st.markdown("---")
    st.subheader("Conversation")
    if st.button("Clear conversation"):
        st.session_state["messages"] = []
        st.success("Conversation cleared")

    if st.button("Save conversation"):
        name = f"conv_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        save_conversation(name, st.session_state["messages"], st.session_state["system_prompt"], st.session_state["persona"])
        st.success(f"Saved as {name}")

    st.markdown("Saved conversations:")
    saved = list_saved_conversations()
    selected = st.selectbox("Load a saved conversation", ["(none)"] + saved)
    if st.button("Load selected"):
        if selected != "(none)":
            conv = load_conversation(selected)
            if conv:
                st.session_state["system_prompt"] = conv.get("system_prompt", st.session_state["system_prompt"])
                st.session_state["persona"] = conv.get("persona", st.session_state["persona"])
                st.session_state["messages"] = conv.get("messages", [])
                st.success(f"Loaded {selected}")
            else:
                st.error("Failed to load selected conversation")

    st.markdown("---")
    st.subheader("Uploads & Context")
    uploaded = st.file_uploader("Upload text files (txt, json, md) to provide context (optional)", accept_multiple_files=True)
    if uploaded:
        st.markdown("Uploaded files added to context (first 50KB each).")
        for f in uploaded:
            try:
                raw = f.getvalue().decode("utf-8", errors="ignore")
                st.session_state.setdefault("uploads", []).append({"name": f.name, "content": raw})
            except Exception as e:
                st.warning(f"Could not read {f.name}: {e}")

    st.markdown("---")
    st.subheader("Advanced")
    st.write("If OpenAI fails, the app falls back to a simple rule-based assistant.")
    st.caption("This is not a full replacement for a hosted LLM but helps keep the chat alive during outages.")

# --- Main UI: messages ---
for message in st.session_state["messages"]:
    role = "user" if message["role"] == "user" else "assistant"
    with st.chat_message(role):
        st.markdown(message["content"])

# --- Input ---
prompt = st.chat_input("Type your message here...")
if prompt:
    st.session_state["messages"].append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    persona_preamble = {
        "Default": "You are a helpful assistant.",
        "Friendly Teacher": "You are a friendly teacher who explains concepts clearly with examples.",
        "Concise Assistant": "You answer as briefly as possible, in bullet points when helpful.",
        "Coder": "You are an expert software engineer. Prefer concise, runnable code examples.",
        "Creative Writer": "You write creatively, vividly, and with evocative metaphors."
    }.get(st.session_state["persona"], "You are a helpful assistant.")

    system_message = {"role": "system", "content": st.session_state["system_prompt"] + " " + persona_preamble}
    messages_payload = [system_message] + st.session_state["messages"][-20:]

    if st.session_state.get("uploads"):
        for up in st.session_state["uploads"][-3:]:
            messages_payload.insert(1, {"role": "system", "content": f"Context file '{up['name']}': {up['content'][:50000]}"})

    reply_text, used_fallback = safe_create_chat_completion(messages_payload)

    st.session_state["messages"].append({"role": "assistant", "content": reply_text})
    with st.chat_message("assistant"):
        if used_fallback:
            st.markdown(f"**(Fallback reply — rule-based)**\n\n{reply_text}")
        else:
            st.markdown(reply_text)
