import os
import openai
import time
import json
from typing import Tuple

CACHE_DIR = os.path.join(os.getcwd(), "saved_conversations")
os.makedirs(CACHE_DIR, exist_ok=True)

def save_conversation(filename: str, messages: list, system_prompt: str, persona: str):
    path = os.path.join(CACHE_DIR, filename)
    payload = {
        "messages": messages,
        "system_prompt": system_prompt,
        "persona": persona,
        "saved_at": __import__("datetime").datetime.utcnow().isoformat() + "Z"
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

def load_conversation(filename: str):
    path = os.path.join(CACHE_DIR, filename)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def list_saved_conversations():
    files = [f for f in os.listdir(CACHE_DIR) if f.endswith(".json")]
    files.sort(reverse=True)
    return files

def simple_rule_based_fallback(user_message: str) -> str:
    """
    Very small rule-based fallback: handles greetings, simple Q/A, and echoes otherwise.
    This is intentionally tiny — real fallback strategies might include local LLMs or cached responses.
    """
    txt = user_message.lower().strip()
    if any(greet in txt for greet in ["hello", "hi", "hey", "good morning", "good evening"]):
        return "Hello! 👋 How can I help you today?"
    if "your name" in txt or "who are you" in txt:
        return "I'm a lightweight fallback assistant running locally."
    if "help me with" in txt or "how do i" in txt:
        return "I can help — please give me more details and I'll provide step-by-step guidance."
    if txt.endswith("?"):
        return "I don't have access to the API right now, but here's a general direction: " + user_message
    # default echo
    return f"(Echo fallback) You said: {user_message}"

def safe_create_chat_completion(messages: list, model: str = "gpt-4o-mini") -> Tuple[str, bool]:
    """
    Try to call OpenAI. On failure, retry a few times with exponential backoff.
    If still failing, return a simple rule-based fallback reply and a flag indicating fallback was used.
    """
    # ensure openai.api_key is set outside
    if not getattr(openai, "api_key", None):
        # try environment
        openai.api_key = os.getenv("OPENAI_API_KEY")

    max_retries = 3
    backoff = 1.0
    for attempt in range(max_retries):
        try:
            resp = openai.ChatCompletion.create(model=model, messages=messages, timeout=30)
            # new OpenAI SDK style places message in resp.choices[0].message.content
            choice = resp.choices[0].message
            text = choice.get("content") if isinstance(choice, dict) else getattr(choice, "content", "")
            return text, False
        except Exception as e:
            # log locally
            try:
                with open("openai_error.log", "a", encoding="utf-8") as logf:
                    logf.write(f"{__import__('datetime').datetime.utcnow().isoformat()} - attempt {attempt+1} - {e}\\n")
            except:
                pass
            time.sleep(backoff)
            backoff *= 2

    # all retries failed: fallback
    user_last = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            user_last = m.get("content", "")
            break
    fallback = simple_rule_based_fallback(user_last or "Hello")
    return fallback, True
